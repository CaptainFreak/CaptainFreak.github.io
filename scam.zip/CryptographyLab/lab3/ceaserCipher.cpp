#include<bits/stdc++.h>
using namespace std;

vector<float> fitfunc(){
	ifstream f;
	vector<float> v;
	f.open("fitness.txt");
	while(!f.eof()){
		char ch;
		float d;
		f>>ch;
		if(ch=='$')
			break;
		f>>d;
		v.push_back(d);		
	}
	f.close();
	return v;
}

float fitness(vector<float> v,string str){
	float s=0.0;
	float l=float(str.length());
	int fre[26]={0};
	for(auto it=str.begin();it!=str.end();it++){
		char x=*(it);
		x=tolower(x)-'a';
		fre[x]++;
	}
	for (int i = 0; i < 26; ++i){
		if((v[i]/100)*l>0){
			s+=pow((float(fre[i])-(v[i]/100)*l),2)/((v[i]/100)*l);
		}
	}
	return s;
}

int main()
{
	vector<float> v=fitfunc();
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		string str;
		cin.get();
		cout<<"Enter the input text: ";
		getline(cin,str);
		int ch;
		cout<<"Encrytion(1) or Decryption(2) or Cryptanalysis(3): ";
		cin>>ch;
		string res="";
		int k;
		switch(ch){
			case 1 :cout<<"Enter the key: ";
					cin>>k;
					for(auto it=str.begin();it!=str.end();it++){
						int x=(*it);
						if(isalpha(x)){
							if(x>=97 && x<=123){
								x-=97;
								x=(x+k)%26;
								res+=char(97+x);
							}
							else{
								x-=65;
								x=(x+k)%26;
								res+=char(65+x);
							}
						}
						else{
							res+=x;
						}
					}
					cout<<"Encrytion is: "<<res<<"\n";
					break;
			case 2 :cout<<"Enter the key: ";
					cin>>k;
					for(auto it=str.begin();it!=str.end();it++){
						int x=(*it);
						k=k%26;
						if(isalpha(x)){
							if(x>=97 && x<=123){
								x-=97;
								x=(x-k);
								if(x<0){
									x=26+x;
								}
								res+=char(97+x);
							}
							else{
								x-=65;
								x=(x-k);
								if(x<0){
									x=26+x;
								}
								res+=char(65+x);
							}
						}
						else{
							res+=x;
						}
					}
					cout<<"Decrytion is: "<<res<<"\n";
					break;
			case 3 :k=0;
					float ff=FLT_MAX;
					int key=0;
					string finals="";
					for(int i=0;i<25;i++){
						k++;
						cout<<"For key:"<<k<<"\n";
						res="";
						for(auto it=str.begin();it!=str.end();it++){
							int x=(*it);
							if(isalpha(x)){
								if(x>=97 && x<=123){
									x-=97;
									x=(x-k);
									if(x<0){
										x=26+x;
									}
									res+=char(97+x);
								}
								else{
									x-=65;
									x=(x-k);
									if(x<0){
										x=26+x;
									}
									res+=char(65+x);
								}
							}
							else{
								res+=x;
							}
						}
						cout<<"Decrytion is: "<<res<<"\n";
						float f=fitness(v,res);
						cout<<f<<"\n";
						if(f<ff){
							finals=res;
							ff=f;
							key=k;
						}
					}
					cout<<"The best Decrytion is:::"<<finals<<"::: with key:"<<key<<"\n";
					break;
		}
	}
	return 0;
}