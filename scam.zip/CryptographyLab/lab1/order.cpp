#include<bits/stdc++.h>
using namespace std;

int gcd(int a,int b){
	if(b==0)
		return a;
	return gcd(b,a%b);
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		int n;
		cout<<"Enter the number: ";
		cin>>n;
		int c=1;
		for(int i=2;i<n;i++){
			if(gcd(n,i)==1)
				c++;
		}
		vector<int> v;
		for(int i=1;i<=c/2;i++)
			if(c%i==0)
				v.push_back(i);
		v.push_back(c);
		for(int i=1;i<n;i++){
			for(auto it=v.begin();it!=v.end();it++){
				int t=*it;
				if((int)pow(i,t)%n==1){
					cout<<i<<" "<<t<<"\n";
					break;
				}
			}
		}
	}
	return 0;
}