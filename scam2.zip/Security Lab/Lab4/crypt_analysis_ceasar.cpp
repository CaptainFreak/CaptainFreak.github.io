#include<bits/stdc++.h>

int MOD = 26;

using namespace std;

string Encrypt(string input, int key)
{
    string code = "";
    for(int i = 0; i < input.size(); i++)
    {
        if(input[i] == ' ')
          code += " ";
        else
          code += (((input[i] - 97 + (key) % MOD) + MOD) % MOD + 97);
    }

    return code;
}

string Decrypt(string code, int key)
{
    string text = "";
    for(int i = 0; i < code.size(); i++)
    {
        if(code[i] == ' ')
          text += " ";
        else
          text += (((code[i] - 97 - (key) % MOD) + MOD) % MOD + 97);

    }
    return text;
}

float fitness(string text, float probab_distribution[])
{
    int s = text.size();
    float score = 0;
    int freq[26] = {0};
    for(int i = 0; i < text.size(); i++)
    {
        if(text[i] != ' ')
            freq[text[i] - 97]++;
    }


    for(int i = 0; i < 26; i++)
    {

        // cout<<freq[i]<<" ";

        if(probab_distribution[i]/100 * s > 0)
        {
            // cout<<"freq[i] = "<<freq[i]<<" original = "<<probab_distribution[i]/100<<" size="<<s <<" score = "<<pow((freq[i] - probab_distribution[i]/100 * s), 2)/(probab_distribution[i] / 100 * s) <<endl;
            score += pow(((float)freq[i] - probab_distribution[i]/100 * s), 2) / (probab_distribution[i] / 100 * s);
        }

    }
    cout<<endl;
    return score;
}

int main()
{
    string input, code;
    int key, choice;

    cout<<"1. Encryption\n";
    cout<<"2. Decryption\n";
    cout<<"3. Crypt Analysis\n";

    cin>>choice;
    getchar();
    if(choice == 1)
    {
        cout<<"Enter the input\n";
        getline(cin, input);
        cout<<"Enter the cipher key\n";
        cin>>key;

        cout<<"Encrypted code = "<<Encrypt(input, key)<<endl;
    }
    else if(choice == 2)
    {
        cout<<"Enter the code\n";
        getline(cin, code);
        cout<<"Enter the cipher key\n";
        cin>>key;


        cout<<" Original text was = "<< Decrypt(code, key)<<endl;
    }
    else if(choice == 3)
    {
        cout<<"Enter the code\n";
        getline(cin, code);

        float probab_distribution[26] = {8.2, 1.5, 2.8, 4.3, 12.7, 2.2, 2.0, 6.1, 7, 0.15, 0.8, 4, 2.4, 6.7, 7.5, 1.9, 0.1, 6.0, 6.3, 9.1, 2.8, 1.0, 0.15, 2.0, 0.07};
        float fitness_score[26] = {0}, min_score = 1000000;
        string decrypted_text[26];
        int freq[26] = {0}, min_idx = 0;
        /*for(int i = 0; i < code.size(); i++)
          freq[code[i] - 97]++;
        char max_char = *max_element(freq, freq + 26) + 97;*/

        for(int i = 0; i < 26; i++)
        {

            decrypted_text[i] = Decrypt(code, i);
            fitness_score[i] = fitness(decrypted_text[i], probab_distribution);
            cout<<"Decryption string "<<i <<" = "<<decrypted_text[i]<<" Score : "<<fitness_score[i] <<endl;
            if(fitness_score[i] < min_score)
            {
                min_idx = i;
                min_score = fitness_score[i];
            }

        }

        cout<<"\n************\n";
        // cout<<min_idx<<endl;
        cout<<"The deciphered text = "<<decrypted_text[min_idx]<<endl;


    }
	return 0;
}
