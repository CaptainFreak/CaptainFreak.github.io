#include<bits/stdc++.h>


using namespace std;

int main()
{
    long long int n, a, b;
    cout<< "Enter odd number \n";
    cin>>n;
    if(n & 1 == 0)
        return 0;
    a = ceil(sqrt(n));

    while(true)
    {
        b = sqrt(a * a - n);
        // cout<<"b="<<b<<endl;

        if(b * b == a * a - n)
            break;
        a++;
    }
    cout<<"Factors are a = "<< a - b<< " b = "<< a + b<<endl;
	return 0;
}
