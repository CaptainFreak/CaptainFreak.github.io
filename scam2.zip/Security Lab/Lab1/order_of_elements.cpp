#include<bits/stdc++.h>
using namespace std;
 
int modulo(int a, int b, int c){
	int ans=1;
	while(b!=0){
		if(b%2 == 1)
			ans = (ans*a)%c;					//(a^b)%c in logarithmic time.
		a=(a*a)%c;
		b/=2;
	}
	return ans;
}
int order(int a, int n){
	for(int i=1; ; i++){
		int ans = modulo(a, i, n);				//If (a^i) = 1 mod n then i is order of a, i should be minimum.
		if(ans==1){
			return i;
		}
	}
}
int gcd(int a, int b){
	if(a==0)
		return b;
	return gcd(b%a, a);
}
int main(){
	int n;
	cout<<"\nEnter n for Zn: ";
	cin>>n;
	vector<int> v;
	for(int i=1; i<=n; i++){
		if(gcd(i, n)==1)						//order exists only for elements which are coprime with n
			v.push_back(i);
	}
	for(int i=0; i<v.size(); i++){
		int ans = order(v[i], n);				//Checking order for all those coprime elements
		cout<<"\n"<<v[i]<<": "<<ans;
	}
	//cout<<modulo(5, 59, 19);
	cout<<endl;
	return 0;
}