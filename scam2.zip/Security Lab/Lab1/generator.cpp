#include <bits/stdc++.h>
using namespace std;
int modulo(int a, int b, int c){
    int ans=1;
    while(b!=0){
        if(b%2 == 1)
            ans = (ans*a)%c;                    //(a^b)%c in logarithmic time.
        a=(a*a)%c;
        b/=2;
    }
    return ans;
}
int gcd(int a, int b){
    if(a == 0)
        return b;
    return gcd(b%a, a);
}

int main(){
    
    int a,n;
    vector <int> v;
    cout<<"\nEnter n: ";
    cin>>n;
    for(int i = 1; i < n; i++){
        if(gcd(i, n) == 1)
            v.push_back(i);
    }
    int phi = v.size();

    for(int i = 0; i < v.size(); i++){
        int j = 1;
        bool flag = true;
        while(j < phi){
            int x = modulo(v[i], j, n);
            if(x == 1){
                flag = false;
                break;
            }
            j++;
        }
        if(j==phi){
            int x = modulo(v[i], j, n);
            if(x  == 1){
                flag=true;
            }
        }
        if(flag){
            cout<<"Generator for "<<n<<" is "<<v[i]<<endl;
            
        }
    }
    return 0;
}