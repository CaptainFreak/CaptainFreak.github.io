#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll modular_expo(ll base,ll exponent, ll modulo){
	ll res;
	while (exponent > 0){
		if(exponent & 1)
			res = (res*base) % modulo;
		exponent = exponent >> 1;
		base = (base*base) % modulo;
	}
	return res;
}

ll Div(ll n){
	if(n == 1)
		return 1;
	if(n%2 ==0)
		return 2;

	ll x = (rand()%(n-2))+2;
	ll y = x;

	ll c = (rand()%(n-1))+1;

	ll d = 1;
	while(d == 1){
		x = (modular_expo(x,2,n) + c)%n;

		y = (modular_expo(y,2,n) + c)%n;
		y = (modular_expo(y,2,n) + c)%n;

		d = __gcd(abs(x-y),n);

		if(d == n) return Div(n);
	}
	return d;
}
int main(){
	ll n,d;
	cout<<"Enter n\n";
	cin>>n;
	d = Div(n);
	cout<<"The Divisor of "<<n<<" is "<<d<<"\n";
	return 0;
}