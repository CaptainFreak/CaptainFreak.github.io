#include<bits/stdc++.h>
using namespace std;

int gcd(int a,int b){
	if(b==0)
		return a;
	return gcd(b,a%b);
}

void gcdEx(int a,int b,int &f1,int &f2){
	if(b==0){
		f1=1;
		f2=0;
	}
	else{
		int x,y;
		gcdEx(b,a%b,x,y);
		f1=y;
		f2=x-(a/b)*y;
	}
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		string str;
		cout<<"Enter the input word: ";
		cin>>str;
		int a,b;
		cout<<"Enter the keys: ";
		cin>>a>>b;
		if(gcd(a,26)!=1){
			cout<<"Incorrect key.";
			continue;
		}
		int ch;
		cout<<"Encrytion(1) or Decryption(2): ";
		cin>>ch;
		string res="";
		switch(ch){
			case 1 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it);
						if(x>=97 && x<=123){
							x-=97;
							x=(a*x+b)%26;
							res+=char(97+x);
						}
						else{
							x-=65;
							x=(a*x+b)%26;
							res+=char(65+x);
						}
					}
					cout<<"Encrytion is: "<<res<<"\n";
					break;
			case 2 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it);
						b=b%26;
						int c,d;
						gcdEx(a,26,c,d);
						if(x>=97 && x<=123){
							x-=97;
							x=(x-b);
							if(x<0){
								x=26+x;
							}
							x=(x*c)%26;
							res+=char(97+x);
						}
						else{
							x-=65;
							x=(x-b);
							if(x<0){
								x=26+x;
							}
							x=(x*c)%26;
							res+=char(65+x);
						}
					}
					cout<<"Decrytion is: "<<res<<"\n";
					break;
			default:cout<<"wrong choice.\n";
		}
	}
	return 0;
}