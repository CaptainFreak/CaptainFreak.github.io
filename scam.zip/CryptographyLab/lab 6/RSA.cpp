#include <bits/stdc++.h>
#include "utils.cpp"

using namespace std;

class RSA
{
    private:
        long long p, q, d; // two primes, p and q, preferably large

        long long ChooseE()
        {
            std::vector<long long> Z_star_n = ZstarN(phi_n);
            return Z_star_n[rand() % Z_star_n.size()];
        }

    public:
        long long n, e, phi_n;

        RSA(int p, int q)
        {
            // 1. Primality testing of p and q
            this->p = p;
            this->q = q;
            // 2.
            n = p * q;
            // 3.
            phi_n = (p - 1) * (q - 1);
            // 4. Choose e, such that gcd(e, phi_n) = 1
            e = ChooseE();
            // 5. Find d, such that d.e = 1 mod phi_n
            d = ModInv(e, phi_n);

            std::cout << e << " " << d << std::endl;
        }

        long long encrypt(long long m)
        {
            cout<<"En = "<<e<<" De = "<<d<<" m = "<<m<<" n = "<<n<<endl;
            return Pow(m, e, n);
        }

        long long decrypt(long long c)
        {
            return Pow(c, d, n);
        }
};


int main(int argc, char const *argv[])
{
    RSA rsa = RSA(3, 5);
    int m = 9;
    int enc = rsa.encrypt(9);
    int dec = rsa.decrypt(enc);
    cout<<"Message = "<<m<<endl;
    cout<<"Encryption = "<<enc<<endl;
    cout<<"Decrypting enc = "<<enc<<" message = "<<dec<<endl;

    return 0;
}
