#include<bits/stdc++.h>
using namespace std;

void gcdEx(int a,int b,int &f1,int &f2){
	if(b==0){
		f1=1;
		f2=0;
	}
	else{
		int x,y;
		gcdEx(b,a%b,x,y);
		f1=y;
		f2=x-(a/b)*y;
	}
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		cout<<"Enter the number of element: ";
		int k;
		cin>>k;
		vector<int> a(k);
		vector<int> n(k);
		cout<<"Enter co-primes: ";
		int N=1;
		for (int i = 0; i < k; ++i){
			cin>>n[i];
			N*=n[i];
		}
		cout<<"Enter the remainders: ";
		for (int i = 0; i < k; ++i){
			cin>>a[i];
		}
		int s=0;
		for (int i = 0; i < k; ++i){
			int bi,pro=a[i];
			bi=N/n[i];
			pro*=bi;
			int x,y;
			gcdEx(bi,n[i],x,y);
			if (x<0){
				x+=n[i];
			}
			pro*=x;
			s=(s+pro);
		}
		cout<<s%N<<"\n";
	}
	return 0;
}