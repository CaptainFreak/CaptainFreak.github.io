#include<iostream>
using namespace std;

int extended_euclid(int a, int b, int *x, int *y){
	if(a==0){
		*x = 0;
		*y = 1;
		return b;
	}

	int x1, y1;
	int gcd = extended_euclid(b%a, a, &x1, &y1);

	*x = y1 - (b/a) * x1;
	*y = x1;
	return gcd;
}
int main(){
	int a,n,x,y;
	cout<<"\nEnter 'a' and 'n' of Zn: ";
	cin>>a>>n;
	//cout<<"\nGCD of "<<a<<" and "<<n<<" is "<<extended_euclid(a, n, &x, &y)<<endl;
	
	if(extended_euclid(a, n, &x, &y)!=1){
		cout<<"\nMultiplicative inverse does not exists.";
	}
	else{
		if(x<0){
			x=x+n;
		}
		cout<<"\nMultiplicative inverse of "<<a<<" in "<<"Z"<<n<<" is "<<x<<endl;
	}
	return 0;
}