#include <vector>
#include <ostream>
#include <cstdlib>

using namespace std;
long long Pow(long long base, unsigned long long power, long long modulo)
{
    long long result = 1;
    base %= modulo;
    while(power > 0)
    {
        if(power & 1)
            result = (result * base) % modulo;
        power >>= 1;
        base = (base * base) % modulo;
    }
    // cout<<"result = "<<result<<endl;
    return result;
}

long long GCD(long long a, long long b)
{
    if(b == 0)
        return a;
    return GCD(b, a % b);
}

long long GCDExtended(long long a, long long b, long long *x, long long *y)
{
    if(b == 0)
    {
        *x = 1, *y = 0;
        return a;
    }
    long long x1, y1;
    long long gcd = GCDExtended(b, a % b, &x1, &y1);
    *x = y1;
    *y = x1 - (a / b) * y1;
    return gcd;
}

long long ModInv(long long a, long long modulo)
{
    long long x, y;
    long long gcd = GCDExtended(modulo, a, &x, &y);

    // TODO: Better error handling
    try
    {
        if(gcd != 1)
            throw -1;
    }
    catch(int err)
    {
        std::cerr << "Inverse of " << a << " mod " << modulo << " does not exist!\n";
        return -1;
        //exit();
    }

    return (y % modulo + modulo) % modulo; // to avoid negative
}

std::vector<long long> ZstarN(long long n)
{
    std::vector<long long>Z_star_n;
    Z_star_n.push_back(1);
    long long gcd = 0;
    for(long long iter = 2; iter < n; iter++)
    {
        gcd = GCD(n, iter);
        if(gcd == 1)
            Z_star_n.push_back(iter);
    }

    return Z_star_n;
}

long long PollardRho(long long n)
{
    // May not always work

    // TODO: Check for primality of n

    while(true)
    {
        srand(time(0));
        long long gcd = 1;
        long long x = rand() % (n - 2) + 2, y = x;
        long long c = rand() % (n - 1) + 1;

        while(gcd == 1)
        {
            x = (Pow(x, 2, n) + c) % n;
            y = (Pow(y, 2, n) + c) % n;
            y = (Pow(y, 2, n) + c) % n;

            gcd = GCD(n, abs(x - y));

            if(gcd != 1)
            {
                if(gcd == n)
                    break;
                return gcd;
            }
        }
    }
}
