#include <bits/stdc++.h>
using namespace std;

int gcd(int a,int b){
	if(b==0)
		return a;
	return gcd(b,a%b);
}

int main(){
    int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		int x,y;
    	int a,n;
    	vector <int> v;
    	cout<<"\nEnter n: ";
    	cin>>n;
    	for(int i = 1; i < n; i++){
    	    if(gcd(i, n) == 1)
    	        v.push_back(i);
    	}
    	int phi = v.size();

    	for(int i = 0; i < v.size(); i++){
    	    int j = 0;
    	    bool flag = true;
    	    while(j++ < phi){
    	        int x = pow(v[i], j);
    	        if(x % n == 1){
    	            flag = false;
    	            break;
    	        }
    	    }
    	    if(flag){
    	        cout<<"Generator for "<<n<<" is "<<v[i]<<endl;
    	        break;
    	    }
    	}
    }
    return 0;
}