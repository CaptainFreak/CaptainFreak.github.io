#include<bits/stdc++.h>
using namespace std;
char arr_lower[26];
char arr_upper[26];
int main(){
	/*for(int i=0; i<26; i++){
		arr_lower[i] = 97 + i;
	}
	for(int i=0; i<26; i++){
		arr_upper[i] = 65 + i;
	}*/

	string s;
	int choice;
	
	char ch='y';
	while(ch=='y'){
		cout<<"\nChoose: ";
		cout<<"\n1.Encryption";
		cout<<"\n2.Decryption";
		int c;	cin>>c;
		getchar();
		int k;
		if(c==1)
		{
				cout<<"\nEnter any text for encryption: ";
				getline(cin, s);
				cout<<"\nEnter key for encryption: ";
				cin>>k;
				string s2="";
				for(int i=0; i<s.size(); i++){
					s2+=((s[i] - 32 + (k%95))%95 + 32);
				}
				cout<<"\nEncrypted text is: "<<s2;
		}
		else{	
				cout<<"\nEnter any text for decryption: ";
				getline(cin,s);
				cout<<"\nEnter key for decryption: ";
				cin>>k;
				string s3="";
				for(int i=0; i<s.size(); i++){
					s3+=((s[i]-32 - (k%95)+95)%95)+32;
				}
				cout<<"\nDecrypted text is: "<<s3;
		}
		cout<<"\nWant to enter more: ";
		cin>>ch;
	}
	
	return 0;
}
