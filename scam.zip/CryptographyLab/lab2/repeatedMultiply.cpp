#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		int n,p;
		cout<<"Enter the number and power: ";
		cin>>n>>p;
		int l=1;
		while(p){
			if(p%2==0){
				n=n*n;
				p/=2;
			}
			else{
				l=n*l;
				p=(p-1);
			}			
		}
		cout<<l<<"\n";
	}
	return 0;
}