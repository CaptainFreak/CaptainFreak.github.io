#include<bits/stdc++.h>
using namespace std;

int gcd(int a,int b){
	if(b==0)
		return a;
	return gcd(b,a%b);
}

void gcdEx(int a,int b,int &f1,int &f2){
	if(b==0){
		f1=1;
		f2=0;
	}
	else{
		int x,y;
		gcdEx(b,a%b,x,y);
		f1=y;
		f2=x-(a/b)*y;
	}
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		string str;
		cin.get();
		cout<<"Enter the input word: ";
		getline(cin,str);
		int a,b;
		cout<<"Enter the keys: ";
		cin>>a>>b;
		if(gcd(a,26)!=1){
			cout<<"Incorrect key.";
			continue;
		}
		int ch;
		cout<<"Encrytion(1) or Decryption(2): ";
		cin>>ch;
		string res="";
		switch(ch){
			case 1 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it)-32;
						x=(a*x+b)%95;
						res+=char(32+x);
					}
					cout<<"Encrytion is: "<<res<<"\n";
					break;
			case 2 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it)-32;
						b=b%95;
						int c,d;
						gcdEx(a,95,c,d);
						x=(x-b);
						if(x<0){
							x=95+x;
						}
						x=(x*c)%95;
						res+=char(32+x);
					}
					cout<<"Decrytion is: "<<res<<"\n";
					break;
			default:cout<<"wrong choice.\n";
		}
	}
	return 0;
}