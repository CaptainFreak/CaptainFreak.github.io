#include<bits/stdc++.h>

using namespace std;
int MOD = 26;


string Encrypt(string input, int a, int b)
{
    string code = "";
    for(int i = 0; i < input.size(); i++)
    {
        if(input[i] == ' ')
          code += " ";
        else
          code += (a * (input[i] - 97) + b) % MOD + 97;


    }

    return code;
}

string Decrypt(string code, int x, int b)
{
    string text = "";
    for(int i = 0; i < code.size(); i++)
    {
        if(code[i] == ' ')
          text += " ";
        else
          text += (x % MOD * (((code[i] - 97) - b % MOD) + MOD) % MOD) % MOD  + 97;

    }
    return text;
}

float fitness(string text, float probab_distribution[])
{
    int s = text.size();
    float score = 0;
    int freq[26] = {0};
    for(int i = 0; i < text.size(); i++)
    {
        if(text[i] != ' ')
        freq[text[i] - 97]++;
    }


    for(int i = 0; i < 26; i++)
    {

        // cout<<(freq[i] - probab_distribution[i] * s)<<" ";

        if(probab_distribution[i]/100 * s > 0)
        {
            // cout<<"freq[i] = "<<freq[i]<<" original = "<<probab_distribution[i]/100<<" size="<<s <<" score = "<<pow((freq[i] - probab_distribution[i]/100 * s), 2)/(probab_distribution[i] / 100 * s) <<endl;
            score += pow(((float)freq[i] - probab_distribution[i]/100 * s), 2) / (probab_distribution[i] / 100 * s);
        }

    }
    cout<<endl;
    return score;
}



int gcd_extended(int a, int b, int &x, int &y)
{
    if(a == 0)
    {
        x=0;
        y=1;
        return b;
    }
    int x1,y1;
    int gcd = gcd_extended(b%a, a, x1, y1);

    x = y1 - (b / a) * x1;
    y = x1;
    return gcd;
}


using namespace std;

int main()
{
    string input, code;
    int a, b, choice, x, y;

    cout<<"1. Encryption\n";
    cout<<"2. Decryption\n";
    cout<<"3. Crypt Analysis\n";

    cin>>choice;
    getchar();
    if(choice == 1)
    {
        cout<<"Enter the input\n";
        getline(cin, input);
        cout<<"Enter the cipher key\n";
        cin>>a >> b;
        if(gcd_extended(a, MOD, x, y) != 1)
        {
            cout<<"Enter correct cipher key\n";
            return 0;
        }


        cout<<"Encrypted code = "<<Encrypt(input, a, b)<<endl;
    }
    else if(choice == 2)
    {
        cout<<"Enter the code\n";
        getline(cin, code);
        cout<<"Enter the cipher key\n";
        cin>>a >> b;
        if(gcd_extended(a, MOD, x, y) != 1)
        {
            cout<<"Enter correct cipher key\n";
            return 0;
        }
        // cout<<"a inverse = "<< x<<endl;

        cout<<"Original text was = "<< Decrypt(code, x, b)<<endl;
    }
    else if(choice == 3)
    {
        cout<<"Enter the code\n";
        getline(cin, code);

        float probab_distribution[26] = {8.2, 1.5, 2.8, 4.3, 12.7, 2.2, 2.0, 6.1, 7, 0.15, 0.8, 4, 2.4, 6.7, 7.5, 1.9, 0.1, 6.0, 6.3, 9.1, 2.8, 1.0, 0.15, 2.0, 0.07};
        float fitness_score[1000] = {0}, min_score = 1000000;
        string decrypted_text[1000];
        int freq[26] = {0}, min_idx = 0;
        for(int i = 0; i < code.size(); i++)
          freq[code[i] - 97]++;
        char max_char = *max_element(freq, freq + 26) + 97;
        int z = 0;
        for(int i = 0; i < 26; i++)
        {
            int x, y;
            if(gcd_extended(i + 1, MOD, x, y) == 1)
            {
                for(int j = 1; j <= 26; j++)
                {
                    decrypted_text[z] = Decrypt(code, (x + MOD) % MOD, j);
                    // cout<<" i = "<< i + 1 <<" j = "<< j<<" x = "<< x<<" decrypted_text = "<<decrypted_text[z]<<endl;
                    fitness_score[z] = fitness(decrypted_text[z], probab_distribution);
                    cout<<"Decryption string "<<z <<" = "<<decrypted_text[z]<<" Score : "<<fitness_score[z]<<endl;
                    if(fitness_score[z] < min_score)
                    {
                        min_idx = z;
                        min_score = fitness_score[z];
                    }
                    z++;
                    cout<<"Ok\n";
                }
            }


        }

        cout<<"\n************\n";
        // cout<<min_idx<<endl;
        cout<<"The deciphered text = "<<decrypted_text[min_idx]<<endl;


    }
	return 0;
}
