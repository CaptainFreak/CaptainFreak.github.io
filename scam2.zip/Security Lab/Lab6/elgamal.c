//elgamal scheme

#include<stdio.h>
#include<math.h>

int inverse(int a,int n){
    int t = 0,newt = 1,t1;
    int r = n,newr = a,r1;
    int quotient;
    while(newr != 0){
        quotient = r/newr;
        t1=t;
        t=newt;
        newt=t1-quotient*newt;
        r1=r;
        r=newr;
        newr=r1-quotient*newr;
    }

    if(r >1){
        printf("a is not invertible\n");
        return -1;
    }
    if(t < 0)
        t = t + n;
    return t;
}
int bigpow(int a,int k,int n)
{
	int b=1;
	if(k==0)
	{
		return b;
	}
	int A=a,count=0,i;
	if(k%2==1)
		b=a;
	int kb[30],k1=k;
	while(k1>=2){
		kb[count]=k1%2;
		count++;
		k1=k1/2;
	}
	kb[count]=1;
	for(i=1;i<=count;i++){
		A=(A*A)%n;
		if(kb[i]==1)
			b=(A*b)%n;
	}
	return b;
}
int main()
{
	int x,y,g,p,k,a,b,M,c,temp;
	printf("Enter the private key : ");
	scanf("%d",&x);
	printf("Enter the public keys g,p : ");
	scanf("%d %d",&g,&p);
	b:
	printf("Enter sesion key : ");
	scanf("%d",&k);
	if(k>=p || k<1)
	{
		printf("Please choose session key between 1 and p-1.\n");
		goto b;
	}
	y=pow(g,x);
	y=y%p;
	printf("Make your choice: \n");
	printf("Enter 1 to encrypt message\n");
	printf("Enter 2 to decrypt message\n");
	printf("Enter 3 to generate signature\n");
	printf("Enter 4 to verify signature\n");
	scanf("%d",&c);
	switch(c)
	{
		case 1: a=pow(g,k);
			a=a%p;
			printf("Enter the message: \n");
			scanf("%d",&M);
			b=pow(y,k)*M;
			b=b%p;
			printf("a = %d\nb = %d\ny = %d\n",a,b,y);
			break;
		case 2: printf("Enter a,b values : ");
			scanf("%d %d",&a,&b);
			a=pow(a,x);
			a=a%p;
			a=inverse(a,p);
			if(a!=-1)
				M=(b*a)%p;
			else
				break;
			printf("Decrypted message is : %d\n",M);
			break;
		case 3: a=pow(g,k);
			a=a%p;
			printf("Enter the message: \n");
			scanf("%d",&M);
			temp = (a*x)%(p-1);
			temp=(M%p)-temp;
			b=temp*(inverse(k,p-1));
			b=b%(p-1);
			if(b<0)
				b=b+(p-1);
			printf("Message is M = %d\n signature (a,b) = (%d , %d)\n",M,a,b);
			break;
		case 4: printf("Enter a,b,M values : ");
			scanf("%d %d %d",&a,&b,&M);
			temp=bigpow(a,b,p);
			a=bigpow(y,a,p);
			temp=a*temp;
			temp=temp%p;
			b=bigpow(g,M,p);
			if(temp == b)
				printf("Signature verified %d %d \n",temp,b);
			else
				printf("Signature is not matching\n");
			break;
	}
	return 0;
}