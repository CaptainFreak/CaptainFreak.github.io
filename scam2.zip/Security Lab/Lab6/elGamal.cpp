//#include <cstdlib>
#include <ctime>
#include "utils.cpp"
#include <bits/stdc++.h>

using namespace std;


struct ElGamalEncryption
{
    long long y1, y2;

    ElGamalEncryption(long long a, long long b)
    {
        y1 = a, y2 = b;
    }

    friend std::ostream& operator << (std::ostream&, ElGamalEncryption);
};

std::ostream& operator << (std::ostream& out, ElGamalEncryption EGE)
{
    out << "(" << EGE.y1 << ", " << EGE.y2 << ")";
    return out;
}

class ElGamal
{
    private:
        long long a;
    public:
        long long p, alpha, beta;

        ElGamal(long long p, long long alpha, long long a)
        {
            this->p = p;
            this->alpha = alpha;
            this->a = a;
            beta = Pow(alpha, a, p);
        }

        long long y1(long long k)
        {
            return Pow(alpha, k, p);
        }

        long long y2(long long m, long long k)
        {
            return (m * Pow(beta, k, p)) % p;
        }

        ElGamalEncryption encrypt(long long m)
        {
            srand(time(0));

            long long k = rand() % (p - 1);
            return ElGamalEncryption(y1(k), y2(m, k));
        }

        long long decrypt(ElGamalEncryption c)
        {
            long long y1 = c.y1, y2 = c.y2;
            return (y2 * ModInv(Pow(y1, a, p), p)) % p;
        }
};
