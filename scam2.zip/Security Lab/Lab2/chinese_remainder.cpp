#include<bits/stdc++.h>
using namespace std;

int extended_euclid(int a, int b, int *x, int *y){
	if(a==0){
		*x = 0;
		*y = 1;
		return b;
	}

	int x1, y1;
	int gcd = extended_euclid(b%a, a, &x1, &y1);

	*x = y1 - (b/a) * x1;
	*y = x1;
	return gcd;
}
int multiplicative_inverse(int a, int n){
	int x,y;
	a=a%n;
	int gcd = extended_euclid(a, n, &x, &y);
	if(x<0)
		x+=n;
	return x;
}
int main(){
	int k;
	vector<int> ni;
	vector<int> ai;
	cout<<"\nEnter number of elements for each array: ";
	cin>>k;
	cout<<"\nEnter pairwise coprime positive integers(ni): ";
	for(int i=0; i<k; i++){
		int ele;	cin>>ele;
		ni.push_back(ele);
	}
	cout<<"\nEnter arbitrary integers: ";
	for(int i=0; i<k; i++){
		int ele;	cin>>ele;
		ai.push_back(ele);
	}
	int N=1;
	for(int i=0; i<ni.size(); i++){
		N*=ni[i];
	}
	vector<int> yi;
	vector<int> zi;
	for(int i=0; i<k; i++){
		yi.push_back(N/ni[i]);
		zi.push_back(multiplicative_inverse(yi[i], ni[i]));
	}
	int x=0;
	for(int i=0; i<k; i++){
		x = x + ai[i]*yi[i]*zi[i];
		x=x%N;
	}
	cout<<"\nThe answer is: "<<x<<endl;
	return 0;
}