#include<bits/stdc++.h>
using namespace std;

void gcdEx(int a,int b,int &f1,int &f2){
	if(b==0){
		f1=1;
		f2=0;
	}
	else{
		int x,y;
		gcdEx(b,a%b,x,y);
		f1=y;
		f2=x-(a/b)*y;
	}
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		int a,n;
		cout<<"Enter a and n: ";
		cin>>a>>n;
		int x,y;
		gcdEx(a,n,x,y);
		if((a*x+n*y)==1){
			int mul=(x%n+n)%n;
			cout<<mul<<"\n";
		}
		else
			cout<<"Inverse doesnt exists for a because a and n are not coprime.\n";

	}
	return 0;
}