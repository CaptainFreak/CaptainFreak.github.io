#include<bits/stdc++.h>
using namespace std;
int gcd(int a, int b){
	if(a==0)
		return b;
	return gcd(b%a, a);
}
int extended_euclid(int a, int b, int *x, int *y){
	if(a==0){
		*x = 0;
		*y = 1;
		return b;
	}

	int x1, y1;
	int gcd = extended_euclid(b%a, a, &x1, &y1);

	*x = y1 - (b/a) * x1;
	*y = x1;
	return gcd;
}
int main(){
	string s;
	int choice;
	string s3="";
	char ch='y';
	while(ch=='y'){
		cout<<"\nChoose: ";
		cout<<"\n1.Encryption";
		cout<<"\n2.Decryption";
		int c;	cin>>c;
		int a,b;
		if(c==1)
		{
				cout<<"\nEnter any text for encryption: ";
				cin>>s;
				lb:
				cout<<"\nEnter a, b for encryption: ";
				cin>>a>>b;
				if(gcd(a,26)!=1){
					cout<<"\nEnter value of a which is coprime to 26";
					goto lb;
				}
				string s2="";
				for(int i=0; i<s.size(); i++){
					s2+=(a*(s[i]-97)+b)%26 + 97;	
				}
				cout<<"\nEncrypted text is: "<<s2;
		}
		else{	
				cout<<"\nEnter any text for decryption: ";
				cin>>s;
				lb1:
				cout<<"\nEnter a, b for decryption: ";
				cin>>a>>b;
				int x,y;
				if(gcd(a,26)!=1){
					cout<<"\nEnter value of a which is coprime to 26";
					goto lb1;
				}
				
				extended_euclid(a, 26, &x, &y);
				
					if(x<0){
						x=x+26;
					}
					
				for(int i=0; i<s.size(); i++){
					s3+= (x % 26 * (((s[i] - 97) - b%26) + 26) % 26)%26 + 97;	
				}			}
				cout<<"\nDecrypted text is: "<<s3;
		}
		cout<<"\nWant to enter more: ";
		cin>>ch;
		return 0;
}
	