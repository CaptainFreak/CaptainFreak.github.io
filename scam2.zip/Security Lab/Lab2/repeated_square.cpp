#include<bits/stdc++.h>
using namespace std;
//int l;
int modulo(int a, int b){
	int ans=1;
	while(b!=0){
		if(b%2 == 1)
			ans = (ans*a);					//(a^b)%c in logarithmic time.
		a=(a*a);
		b/=2;
		//l++;
	}
	return ans;
}
int main(){
	int a,b,n;
	cout<<"\nEnter values of a and b (a^b): ";
	cin>>a>>b;
	int ans=modulo(a,b);
	cout<<"\nResult of a^b: "<<ans<<endl;
	//cout<<"L: "<<l<<endl;
	return 0;
}