#include<bits/stdc++.h>
using namespace std;

#define MAX 5
char matrix[MAX][MAX];
char not_present;
bool duplicate(int x, int y, char c){
	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			if(matrix[i][j] == c)
				return true;
			if((int)matrix[i][j] == 0)
				return false;
		}
	}
	return false;
}
void fill_matrix(string key){
	int k=0;
	//cout<<"\nlen: "<<key.size()<<endl;

	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			if((int)matrix[i][j] == 0 && (int)key[k]!=32 && !duplicate(i, j, key[k])){
				matrix[i][j] = key[k];
				k++;
			}else{
				j-=1;
				k++;
			}
			if(k==key.size())
				break;
		}
		if(k==key.size())
			break;
	}
	char a[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t','u','v','w','x','y','z'};
	k=0;

	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			if((int)matrix[i][j] == 0 && !duplicate(i, j, a[k])){
				matrix[i][j] = a[k];
				k++;
			}
			else if((int)matrix[i][j] == 0 && duplicate(i, j, a[k])){
				j-=1;
				k++;
			}
			if(k==25)
				break;
		}
		if(k==25)
			break;
	}
	/*k=0;
	int flag=0;
	cout<<"Here"<<endl;
	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			cout<<"a: "<<a[k]<<"k: "<<k<<endl;
			if(!duplicate(i, j, a[k])){
				flag=1;
				k++;
				break;
			}
			k++;
		}
		if(flag){
			not_present = a[k];
			break;
		}
	}*/
}

void print_matrix(){
	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			cout<<matrix[i][j]<<" ";
		}
		cout<<endl;
	}
}

vector< pair<char, char> > v;
vector< pair<char, char> > encrypted_text;
vector< pair<char, char> > d;
vector< pair<char, char> > decrypted_text;
pair<char, char> find(char c1, char c2){
	int p1i,p1j,p2i,p2j;
	pair<char, char> p;
	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			if(matrix[i][j] == c1){
				p1i=i;	p1j=j;
			}
			if(matrix[i][j] == c2){
				p2i=i;	p2j=j;
			}
		}
	}
	if(p1j == p2j){
		p.first = matrix[(p1i + 1)%5][p1j];
		p.second = matrix[(p2i + 1)%5][p2j];
	}
	else if(p1i == p2i){
		p.first = matrix[p1i][(p1j + 1)%5];
		p.second = matrix[p2i][(p2j + 1)%5];
	}
	else{
		p.first = matrix[p1i][p2j];
		p.second = matrix[p2i][p1j];
	}
	return p;
}
void encrypt(){
	for(int i=0; i<v.size(); i++){
		pair<char, char> p = find(v[i].first, v[i].second);
		encrypted_text.push_back(p);
	}
}

pair<char, char> find2(char c1, char c2){
	int p1i,p1j,p2i,p2j;
	pair<char, char> p;
	for(int i=0; i<MAX; i++){
		for(int j=0; j<MAX; j++){
			if(matrix[i][j] == c1){
				p1i=i;	p1j=j;
			}
			if(matrix[i][j] == c2){
				p2i=i;	p2j=j;
			}
		}
	}
	if(p1j == p2j){
		p.first = matrix[(p1i - 1 + 5)%5][p1j];
		p.second = matrix[(p2i - 1 + 5)%5][p2j];
	}
	else if(p1i == p2i){
		p.first = matrix[p1i][(p1j - 1 + 5)%5];
		p.second = matrix[p2i][(p2j - 1 + 5)%5];
	}
	else{
		p.first = matrix[p1i][p2j];
		p.second = matrix[p2i][p1j];
	}
	return p;
}
void decrypt(){
	for(int i=0; i<v.size(); i++){
		pair<char, char> p = find2(d[i].first, d[i].second);
		decrypted_text.push_back(p);
	}
}
int main(){
	string key;
	cout<<"\nEnter the key for playfair cipher: ";
	getline(cin, key);
	cout<<"\nKey: "<<key<<endl;
	//cout<<"\nCHar: "<<(int)matrix[0][0]<<(int)matrix[1][1]<<(int)matrix[0][2]<<endl;
	fill_matrix(key);
	cout<<"\nMatrix: "<<endl;
	print_matrix();
	
	string text;
	cout<<"\nEnter the string you want to encrypt: ";

	
	getline(cin, text);
	cout<<"\ntext: "<<text<<endl;
	for(int i=0; i<text.size();){
		if(text[i]==' '){
			i++;
			continue;
		}
		if(i+1 == text.size()){
			v.push_back(make_pair(text[i], 'z'));
			break;
		}
		else if((int)text[i+1] == 32){
			v.push_back(make_pair(text[i], text[i+2]));
			i+=3;
		}
		else{
			v.push_back(make_pair(text[i], text[i+1]));
			i+=2;
		}
	}

	for(int i=0; i<v.size(); i++){
		cout<<v[i].first<<v[i].second<<" ";
	}

	encrypt();
	cout<<endl;
	cout<<"\nEncrypted text is: ";
	for(int i=0; i<encrypted_text.size(); i++){
		cout<<encrypted_text[i].first<<encrypted_text[i].second<<" ";
	}
	cout<<endl;

	cout<<"\nEnter text for decryption: ";
	string dtext;
	getline(cin, dtext);

	for(int i=0; i<dtext.size();){
		if(dtext[i]==' '){
			i++;
			continue;
		}
		if(i+1 == dtext.size()){
			d.push_back(make_pair(dtext[i], 'z'));
			break;
		}
		else if((int)dtext[i+1] == 32){
			d.push_back(make_pair(dtext[i], dtext[i+2]));
			i+=3;
		}
		else{
			d.push_back(make_pair(dtext[i], dtext[i+1]));
			i+=2;
		}
	}
	decrypt();

	cout<<"\nDecrypted text is: ";
	for(int i=0; i<encrypted_text.size(); i++){
		cout<<decrypted_text[i].first<<decrypted_text[i].second;
	}
	cout<<endl;
	return 0;
}