#include<bits/stdc++.h>
using namespace std;

void gcdEx(int a,int b,int &f1,int &f2){
	if(b==0){
		f1=1;
		f2=0;
	}
	else{
		int x,y;
		gcdEx(b,a%b,x,y);
		f1=y;
		f2=x-(a/b)*y;
	}
}

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		int a,b;
		cout<<"Enter the numbers: ";
		cin>>a>>b;
		int x,y;
		gcdEx(a,b,x,y);
		int g=a*x+b*y;
		cout<<g<<"\n";
	}
	return 0;
}