#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	cout<<"Enter the number of testcases: ";
	cin>>t;
	while(t--){
		string str;
		cin.get();
		cout<<"Enter the input word: ";
		getline(cin,str);
		int k;
		cout<<"Enter the key: ";
		cin>>k;
		int ch;
		cout<<"Encrytion(1) or Decryption(2): ";
		cin>>ch;
		string res="";
		switch(ch){
			case 1 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it)-32;
						x=(x+k)%95;
						res+=char(32+x);
					}
					cout<<"Encrytion is: "<<res<<"\n";
					break;
			case 2 :for(auto it=str.begin();it!=str.end();it++){
						int x=(*it)-32;
						k=k%95;
						x=(x-k);
						if(x<0){
							x=95+x;
						}
						res+=char(32+x);
					}
					cout<<"Decrytion is: "<<res<<"\n";
					break;
			default:cout<<"wrong choice.\n";
		}
	}
	return 0;
}